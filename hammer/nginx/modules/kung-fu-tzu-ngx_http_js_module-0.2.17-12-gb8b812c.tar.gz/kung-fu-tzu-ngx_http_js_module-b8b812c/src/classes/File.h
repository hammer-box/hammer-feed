#ifndef _NGX_HTTP_JS_NGINX_FILE_H_INCLUDED_
#define _NGX_HTTP_JS_NGINX_FILE_H_INCLUDED_

extern JSClass ngx_http_js__nginx_file__class;
extern JSObject *ngx_http_js__nginx_file__prototype;

extern JSBool
ngx_http_js__nginx_file__init(JSContext *cx, JSObject *global);

#endif
