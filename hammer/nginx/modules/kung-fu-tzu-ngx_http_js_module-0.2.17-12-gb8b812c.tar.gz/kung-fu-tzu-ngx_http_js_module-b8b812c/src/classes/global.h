#ifndef _NGX_HTTP_JS_GLOBAL_H_INCLUDED_
#define _NGX_HTTP_JS_GLOBAL_H_INCLUDED_

extern JSBool
ngx_http_js__global__init(JSContext *cx);


#endif
