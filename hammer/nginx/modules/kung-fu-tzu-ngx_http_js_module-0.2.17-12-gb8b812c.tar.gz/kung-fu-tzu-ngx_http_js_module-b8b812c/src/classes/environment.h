#ifndef _NGX_HTTP_JS_ENVIRONMENT_H_INCLUDED_
#define _NGX_HTTP_JS_ENVIRONMENT_H_INCLUDED_

extern JSBool
ngx_http_js__environment__init(JSContext *cx, JSObject *global);


#endif
