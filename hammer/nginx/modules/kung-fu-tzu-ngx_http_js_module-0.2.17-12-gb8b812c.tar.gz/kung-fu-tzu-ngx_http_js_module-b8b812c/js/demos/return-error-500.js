;(function(){

NginxDemos.returnError500 = function (r)
{
	return Nginx.HTTP_INTERNAL_SERVER_ERROR
}

})();