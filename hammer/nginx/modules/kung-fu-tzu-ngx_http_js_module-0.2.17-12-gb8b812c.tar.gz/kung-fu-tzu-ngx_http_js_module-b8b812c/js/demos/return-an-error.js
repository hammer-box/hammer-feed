;(function(){

NginxDemos.returnAnError = function (r)
{
	return Nginx.ERROR
}

})();