
/*
 * Copyright (C) Alacner Zhang (alacner@gmail.com)
 */


#ifndef STRTOK_R_H
#define STRTOK_R_H

char * strtok_r(char *s, const char *delim, char **last);

#endif /* STRTOK_R_H */
