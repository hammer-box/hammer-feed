#ifndef NGX_HTTP_LUA_SLEEP_H
#define NGX_HTTP_LUA_SLEEP_H


#include "ngx_http_lua_common.h"


void ngx_http_lua_inject_sleep_api(lua_State *L);


#endif /* NGX_HTTP_LUA_SLEEP_H */
