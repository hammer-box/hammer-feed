#ifndef NGX_HTTP_LUA_URI_H
#define NGX_HTTP_LUA_URI_H


#include "ngx_http_lua_common.h"


void ngx_http_lua_inject_req_uri_api(ngx_log_t *log, lua_State *L);


#endif /* NGX_HTTP_LUA_URI_H */

